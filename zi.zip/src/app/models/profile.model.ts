export interface IProfile {
  name: string;
  photo: string;
  badges: string[];
}
