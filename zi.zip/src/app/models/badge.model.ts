export interface IBadge {
  name: string;
  description: string;
  photo: string;
  version: number;
  orgId: string;
  updates: string[];
  awards: string[];
  created: number;
  updated?: number;
}
