export interface IAward {
  name: string;
  notes?: string;
  badgeId: string;
  version: number;
  updates: string[];
  updated?: number;
}
