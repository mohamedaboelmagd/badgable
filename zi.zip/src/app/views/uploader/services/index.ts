import { UploaderService } from './uploader.service';

export const SERVICES: any[] = [UploaderService];

export * from './uploader.service';
