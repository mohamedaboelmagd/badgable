import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show-badges',
  templateUrl: './show-badges.component.html',
  styleUrls: ['./show-badges.component.css']
})
export class ShowBadgesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
