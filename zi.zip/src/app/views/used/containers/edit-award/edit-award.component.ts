import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-award',
  templateUrl: './edit-award.component.html',
  styleUrls: ['./edit-award.component.css']
})
export class EditAwardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
