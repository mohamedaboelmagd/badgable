import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-log-award',
  templateUrl: './log-award.component.html',
  styleUrls: ['./log-award.component.css']
})
export class LogAwardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
