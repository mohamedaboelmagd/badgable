module.exports = {
  node: {
    crypto: true,
    http: true,
    https: true,
    os: true,
    vm: true,
    stream: true,
    fs: 'empty',
    child_process: 'empty'
  }
};
